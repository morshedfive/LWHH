<?php 

add_action('after_setup_theme', 'assignment_setup');
function assignment_setup (){
    load_theme_textdomain( 'assignment' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
}

add_action ('wp_enqueue_scripts', 'assignment_scripts');
function assignment_scripts (){
    wp_enqueue_style( 'bootstrap', '//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css');
    wp_enqueue_style('assignment-css', get_stylesheet_uri(  ));
}